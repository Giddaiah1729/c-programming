#include <REGX51.H>
sbit sw=P2^1;
void serialstr(char *);
void delay(int);
void main()
{
	TMOD=0x20;
	SCON=0x50;
	TH1=-3;
	TR1=1;
	sw=1;
	while(1)
	{
	if(sw==0)
	{
		serialstr("AT\r");
		delay(50);
		serialstr("AT+CMGS=\"+916301834437\"\r");
		delay(50);
		serialstr("FROM GSM\r");
		delay(50);
		SBUF=0x01;
		while(TI==0);
		TI=0;
		SBUF=0x1A;
		while(TI==0);
		TI=0;
	}
}
	}
void serialstr(char *x)
{
	while(*x)
	{
		SBUF=*x;
		while(TI==0);
		TI=0;
	x++;
	}
}

void delay(int p)
{
	int i,j;
	for(i=0;i<p;i++);
	for(j=0;j<3000;j++);
}

		