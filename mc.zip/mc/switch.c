#include <REGX51.H>
sbit led=P2^0;
sbit sw1=P2^5;
void main()
{
	sw1=1;
	led=0;
	while(1)
	{
		if(sw1==0)
		
			led=1;
		 else
			led=0;
		
	}
}