#include <REGX51.H>
//#define lcd_data P3 
sbit rs=P2^0;
sbit rw=P2^1;
sbit en=P2^2;
void lcd_cmd(char x);
void lcd_data(char y);
void delay();
void main()
{
	
	//P3=0x00;
	while(1)
	{
	lcd_cmd(0x38);
	delay();
	lcd_cmd(0x01);
	delay();
	lcd_cmd(0x06);
	delay();
	lcd_cmd(0x0c);
	delay();
	lcd_cmd(0x80);
	delay();
	lcd_data('B');
	delay();
	lcd_data('U');
	delay();
	lcd_data('N');
	delay();
	lcd_data('N');
	delay();
	lcd_data('Y');
	delay();
	}
}

	void lcd_cmd(char a)
	{
	
		P3=a;
		rw=0;
		rs=0;
		en=1;
		delay();
		en=0;
	}
	void lcd_data(char b)
	{
		P3=b;
		rw=0;
		rs=1;
		en=1;
		delay();
		en=0;
	}
	void delay()
	{
		int i;
		for(i=0; i<12000; i++);
		
	}
	
		
