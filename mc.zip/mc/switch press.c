#include <REGX51.H>
sbit led = P2^0;
sbit sw = P2^6;
void main()
{
	bit flag;
	led = 0;
	sw = 1;
	flag=0;
	
	while(1)
	{
	if(sw == 0)
	{
		flag =~flag;
		while(sw==0);
	}
	if(flag==0)
	{
		led=1;
		//else
		led=0;

	}
}
	}
		
	