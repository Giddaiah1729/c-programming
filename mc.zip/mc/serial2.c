#include <REGX51.H>
sbit led = P2^7;
void main()
{
	char x;
	TMOD=0x20;
	TH1=0xFD;
	TR1=1;
	SCON=0x50;
	while(1)
	{
		while(RI==0);
		RI=0;
		x=SBUF;
		SBUF=x;
		while(TI==0);
		TI=0; 
    if(x=='0')
    led=1;
    if(x=='1')
	  led=0;
	}
}