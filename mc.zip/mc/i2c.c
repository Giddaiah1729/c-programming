#include <REGX51.H>
void main()
{
	char x;
	bit d0,d1,d2,d3,d4,d5,d6,d7;
	  x=0x55;
	  d0=x&0x80;
		d1=x&0x40;
		d2=x&0x20;
		d3=x&0x10;
		d4=x&0x08;
		d5=x&0x04;
		d6=x&0x02;
		d7=x&0x01;

}
	