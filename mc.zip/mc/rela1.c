#include <REGX51.H>
sbit relay=P2^0;
void main()
{
	int i;
	while(1)
	{
	
	relay=1;
	for(i=0; i<3000; i++);
	relay=0;
	for(i=0; i<3000; i++);
}
	}