#include <reg51.h>
sbit  rs =P3^0;
sbit rw =P3^1;
sbit en =P3^2;

void delay(int count) {
    while (count--);
}

void LCD_cmd(char a)
	{
		P2 = a;
		rs=0;
		rw=0;
		en=1;
    delay(500);
    en = 0;
}
void LCD_display(char b) {
	P2=b;
    rs = 1;
    rw = 0;
    en = 1;
    delay(500);
    en = 0;
}

void main() {
     int i, j;
	  LCD_cmd(0x38); 
    LCD_cmd(0x0E);  
    LCD_cmd(0x01);  
    LCD_cmd(0x80); 
       
    
    for (i = 0; i < 10; i++) {
        for (j = 0; j < 10; j++) {     
                    LCD_cmd(0x01);  
                    LCD_display(i + '0');
                    LCD_display(j + '0');
                    delay(30000);   
                }
            }
        
}