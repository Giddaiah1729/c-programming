#include <REGX51.H>
void serialstring(char *);
void main()
{
	TMOD=0x20;
	SCON=0x50;
	TH1=-3;
	TR1=1;
	serialstring("WELCOM TO MY SYSTEM \r");
	//while(1);
}
void serialstring(char *s)
{
	while(*s)
	//while(*s!='\0')
	{
		SBUF=*s;
		while(TI==0);
			TI=0;
		s++;
	}
}