#include <REGX51.H>
void delay(int);
void main()
{

P2=P1;
	
//delay();
}
