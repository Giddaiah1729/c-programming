#include <REGX51.H>
sbit sw=P1^0;
sbit out=P3^0;
void main()
{
	while(1)
	{
		if(sw==0)
		{
			out=1;
		}
		else
		out=0;
	}
}