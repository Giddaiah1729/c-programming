#include <REGX51.H>
sbit motp=P1^0;
sbit motn=P1^2;
sbit sw=P2^0;

void main()
{
	int i;
	sw=1;
	motp=motn=0;
	while(1)
	{
		if(sw==0)
		{
		motp=1;
		motn=0;
		for(i=0;i<5000;i++);
	}
		else
		{
			motp=motn=0;
		}
}
	
}