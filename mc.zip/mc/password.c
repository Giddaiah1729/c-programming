#include <REGX51.H>
sbit r0=P1^0;
sbit r1=P1^1;
sbit r2=P1^2;
sbit r3=P1^3;
sbit c0=P1^4;
sbit c1=P1^5;
sbit c2=P1^6;

sbit rs=P3^0;
sbit rw=P3^1;
sbit en=P3^2;

sbit motp=P3^3;
sbit motn=P3^4;

void cmd(char);
void dat(char);
void show(char * ,char );
void delay();
void check();
char psw[10],x;

void main()
{
	cmd(0x38);
	cmd(0x01);
	cmd(0x10);
	cmd(0x0c);
	cmd(0x80);
	
	show("PASSWORD PROTECTION",19);
	cmd(0xc0);
	show("SYSTEM",7);
	
		cmd(0x01);
		show("ENTER PASSWORD",14);
		cmd(0xc0);
		while(1)
	{
		r0=0;
		if(c0==0)
		{
			psw[x]='1';
			delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();
			dat('*');	
			x=x+1;
		}
		if(c1==0)
		{
			psw[x]='2';		
			delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();
			dat('*');
			x=x+1;
		}
		if(c2==0)
		{
			psw[x]='3';
			delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();
			dat('*');
			x=x+1;
		}
		
		
		r0=1;r1=0;
		if(c0==0)
		{
			psw[x]='4';
			delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();
			dat('*');
			x=x+1;
		}
			if(c1==0)
		{
			psw[x]='5';
			delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();
			dat('*');
			x=x+1;
		}
			if(c2==0)
		{
			psw[x]='6';
			delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();
			dat('*');
			x=x+1;
		}
		
		
		r1=1;r2=0;
		if(c0==0)
		{
			psw[x]='7';
			delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();
			dat('*');
			x=x+1;
		}
		if(c1==0)
		{
			psw[x]='8';
			delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();
			dat('*');
			x=x+1;
		}
		if(c2==0)
		{
			psw[x]='9';
			delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();
			dat('*');
			x=x+1;
		}
		
		r2=1;r3=0;
		if(c0==0)
		{
			psw[x]='*';
			delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();
			dat('*');
			x=x+1;
		}
		if(c1==0)
		{
			psw[x]='0';
			delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();
			dat('*');
			x=x+1;
		}
		if(c2==0)
		{
			check();
			delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();delay();
			//psw[x]='#';
			//delay();
			//dat('*');
			//x=x+1;
		}
		r3=1;
	}
}
void check()
{
	if(psw[0]=='1'&&psw[1]=='7'&&psw[2]=='2'&&psw[3]=='9')
	{
		motp=1;
		motn=0;
		cmd(0x01);
		show("PASSWORD MATCHED",16);
		delay();
	}
	else
	{
		cmd(0x01);
		show("PASSWORD WORNG",14);
	}
}

void cmd(char x)
{
	P2=x;
	rs=0;
	rw=0;
	en=1;
	delay();
	en=0;
}
void dat(char y)
{
	P2=y;
	rs=1;
	rw=0;
	en=1;
	delay();
	en=0;
}
void show(char *s , char r)
{
char k;
	for(k=0;k<r;k++)
	{
		dat(s[k]);
		delay();
	}
}
void delay()
{
	int i,j;
	for(i=0;i<5000;i++);
	for(j=0;j<5000;j++);
}