#include <REGX52.H>
sbit r0=P1^0;
sbit r1=P1^1;
sbit r2=P1^2;
sbit r3=P1^3;
sbit c0=P1^4;
sbit c1=P1^5;
sbit c2=P1^6;
void seg(int );
void main()
{
	r0=r1=r2=r3=1;
	r0=0;
	if(c0==0)
		seg(0x06);
	
	r0=r1=r2=r3=1;
	r0=0;
	if(c1==0)
		seg(0x5b);
	
	r0=r1=r2=r3=1;
	r0=0;
	if(c2==0)
		seg(0x4f);
	
	r0=r1=r2=r3=1;
	r1=0;
	if(c0==0)
		seg(0x66);
	
	r0=r1=r2=r3=1;
	r1=0;
	if(c1==0)
		seg(0x6d);
	
	r0=r1=r2=r3=1;
	r1=0;
	if(c2==0)
		seg(0x7d);
	
	r0=r1=r2=r3=1;
	r2=0;
	if(c0==0)
		seg(0x07);
	r0=r1=r2=r3=1;
	r2=0;
	if(c1==0)
		seg(0x7f);
	r0=r1=r2=r3=1;
	r2=0;
	if(c2==0)
		seg(0x6f);
	
	r0=r1=r2=r3=1;
	r3=0;
	if(c0==0)
		seg('*');
	r0=r1=r2=r3=1;
	r3=0;
	if(c1==0)
		seg(0x3f);
	r0=r1=r2=r3=1;
	r3=0;
	if(c2==0)
		seg('#');
}
void seg(int x)
{
	P2=0x00;
	P2=x;
}