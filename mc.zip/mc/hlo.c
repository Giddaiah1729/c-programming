#include <REGX51.H>
sbit sw1=P1^2;
sbit led=P2^1;
void main()
{
	sw1=1;
	led=0;
	while(1)
	{
		if(sw1==0)
		
			led=1;
		 else
			led=0;

	}
}