#include <REGX51.H>
//sbit sw=P3^0;
void delay(int);
void main()
{
	//int i;
	//sw=0;
	
	while(1)
	{
	
	//if(sw==1)
	{
		P2=0xcc;
		delay(50);
		
		P2=0xcc;
		delay(50);		
}
}
}
void delay(int x)
{
	int i,j;
	for(i=0;i<x;i++);
	for(j=0;j<5000;j++);
}


/*{
		P2=0x0f;
		for(i=0;i<5000;i++);
		P2=0xf0;
		for(i=0;i<5000;i++);
	}*/