#include <REGX51.H>
sbit sw1=P2^0;
sbit sw2=P2^1;
void main()
{
	sw1=1;
	sw2=1;
	TMOD=0x20;
	SCON=0x50;
	TH1=-3;
	TR1=1;
	if(sw1==0)
	{
		SBUF='1';
		while(TI==0);
			TI=0;
		while(sw1==0);
	}
	
	if(sw2==0)
	{
		SBUF= '0';
		while(TI==0);
			TI=0;
		while(sw2==0);
	}
}
		