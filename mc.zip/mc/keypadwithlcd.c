/*#include <REGX51.H>
sbit rs=P2^0;
sbit rw=P2^1;
sbit en=P2^2;

sbit r0=P1^0;
sbit r1=P1^1;
sbit r2=P1^2;
sbit r3=P1^3;
sbit c0=P1^4;
sbit c1=P1^5;
sbit c2=P1^6;
sbit c3=P1^7;
void lcd_data(char );
void cmd(char );
void show(char *);
void delay();

void delay(int x)  
{
	int i,j ;
 for(i=0;i<x;i++)   
 for(j=0;j<1275;j++);
}

void cmd(char y)  
{
    P3 = y;
    rs= 0;
    rw=0;
    en=1;
    delay(1);
    en=0;
}


void lcd_data(char z)  
{
    P3=z;
    rs= 1;
    rw=0;
    en=1;
    delay(1);
    en=0;
}

void show(char *s)
{
	while(*s)
	{
		lcd_data(*s++);
	}
}

 void main()    
{
	int i,j;
	char key[4][4];
  cmd(0x38);
	delay(10);
	cmd(0x01);
	delay(10);
	cmd(0x0c);
	delay(10);
	cmd(0x06);
	delay(10);
	cmd(0x80);
	delay(10);
	
 key[4][4]=('0', '1', '2','3','4','5','6','7','8','9','A','B','C','D','E','F');
 while(1)
	{
	
r0=r1=r2=r3=1;
c0=c1=c2=c3=0;
	
if(r0==0) j=0;
if(r1==0) j=1;
if(r2==0) j=2;
if(r3==0) j=3;
		
r0=r1=r2=r3=0;
c0=c1=c2=c3=1;
	
if(c0==0) i=0;
if(c1==0) i=1;
if(c2==0) i=2;
if(c3==0) i=3;

		lcd_data(key[1][0]);
	}
}

*/

#include <REGX51.H>
sbit rs=P2^0;
sbit rw=P2^1;
sbit en=P2^2;

sbit r0=P1^0;
sbit r1=P1^1;
sbit r2=P1^2;
sbit r3=P1^3;
sbit c0=P1^4;
sbit c1=P1^5;
sbit c2=P1^6;
sbit c3=P1^7;
sfr lcd=0xb0;
void delay();
void cmd(char );
void lcd_data(char );
void show(char *);
void main()
{
	cmd(0x38);
	delay();
	cmd(0x01);
	delay();
	cmd(0x06);
	delay();
	cmd(0x0c);
	delay();
	cmd(0x80);
	delay();
	 while(1)
	{
		r0=0;
		if(c0==0)
		{
			lcd_data('7');
		delay();delay();delay();delay();delay();delay();
		}
		if(c1==0)
		{
			lcd_data('8');
		delay();delay();delay();delay();delay();delay();
		}
		if(c2==0)
		{
			lcd_data('9');
		delay();delay();delay();delay();delay();delay();delay();
		}
		if(c3==0)
		{
			lcd_data('%');
		delay();delay();delay();delay();delay();delay();
		}
		
		
		r0=1;r1=0;
		if(c0==0)
		{
			lcd_data('4');
		delay();delay();delay();delay();delay();delay();
		}
		if(c1==0)
		{
			lcd_data('5');
		delay();delay();delay();delay();delay();delay();
		}
		if(c2==0)
		{
			lcd_data('6');
		delay();delay();delay();delay();delay();delay();
		}
		if(c3==0)
		{
			lcd_data('*');
		delay();delay();delay();delay();delay();delay();
		}
		
		
		r1=1;r2=0;
		if(c0==0)
		{
			lcd_data('1');
		delay();delay();delay();delay();delay();delay();
		}
		if(c1==0)
		{
			lcd_data('2');
		delay();delay();delay();delay();delay();delay();delay();
		}
		if(c2==0)
		{
			lcd_data('3');
		delay();delay();delay();delay();delay();delay();delay();
		}
		if(c3==0)
		{
			lcd_data('-');
		delay();delay();delay();delay();delay();delay();
		}
		
		
		r2=1;r3=0;
		if(c0==0)
		{
			lcd_data("A");
		delay();delay();delay();delay();delay();delay();delay();
		}
		if(c1==0)
		{
			lcd_data('0');
		delay();delay();delay();delay();delay();delay();delay();
		}
		if(c2==0)
		{
			lcd_data('=');
		delay();delay();delay();delay();delay();delay();delay();delay();
		}
		if(c3==0)
		{
			lcd_data('+');
		delay();delay();delay();delay();delay();delay();delay();delay();
		}
		r3=1;
	}
}
void cmd(char x)
{
	P0=x;
	rs=0;
	rw=0;
	en=1;
	delay();
	en=0;
}
void lcd_data(char y)
{
	P0=y;
	rs=1;
	rw=0;
	en=1;
	delay();
	en=0;
}

/*void show(char *s)
{
	while(*s)
	{
		lcd_data(*s++);
	}
}*/

void delay()
{
	int i,j;
	for(i=0;i<5000;i++);
	for(j=0;j<5000;j++);
}
	
	
	
	
	/*
#include<reg51.h>

#define lcd P3

sbit rs=P2^0;
sbit rw=P2^1;
sbit en=P2^2;

sbit r1=P1^0;
sbit r2=P1^1;
sbit r3=P1^2;
sbit r4=P1^3;
sbit c1=P1^4;
sbit c2=P1^5;
sbit c3=P1^6;
sbit c4=P1^7;

                  
void lcd_init();
void cmd(char );
void dat(char );
lcd_string(char *);
void delay(int );
void keypad(void);


void main()
{
    lcd_init();
    while(1) {
        cmd(0x80);
        lcd_string("Enter the key:");
        cmd(0xc7);
        keypad();
    }
}

void keypad()
{
    c1=c2=c3=c4=1;
    r1=0;r2=1;r3=1;r4=1;
    if(c1==0){
        while(c1==0);
        dat('7');
    } else if(c2==0) {
        while(c2==0);
        dat('8');
    } else if(c3==0) {
        while(c3==0);
        dat('9');
    } else if(c4==0) {
        while(c4==0);
        dat('/');
    }

    r1=1;r2=0;r3=1;r4=1;
    if(c1==0){
        while(c1==0);
        dat('4');
    } else if(c2==0) {
        while(c2==0);
        dat('5');
    } else if(c3==0) {
        while(c3==0);
        dat('6');
    } else if(c4==0) {
        while(c4==0);
        dat('*');
    }

    r1=1;r2=1;r3=0;r4=1;
    if(c1==0){
        while(c1==0);
        dat('1');
    } else if(c2==0) {
        while(c2==0);
        dat('2');
    } else if(c3==0) {
        while(c3==0);
        dat('3');
    } else if(c4==0) {
        while(c4==0);
        dat('-');
    }

    r1=1;r2=1;r3=1;r4=0;
    if(c1==0){
        while(c1==0);
        cmd(0x01);
    } else if(c2==0) {
        while(c2==0);
        dat('0');
    } else if(c3==0) {
        while(c3==0);
        dat('=');
    } else if(c4==0) {
        while(c4==0);
        dat('+');
    }
}


void lcd_init()
{
        cmd(0x38);
        cmd(0x0e);
        cmd(0x06);
        cmd(0x01);
}

void cmd(char x)
{
        lcd=x;
        rs=0;
        rw=0;
        en=1;
        delay(1000);
        en=0;
}

void dat(char y)
{
        lcd=y;
        rs=1;
        rw=0;
        en=1;
        delay(1000);
        en=0;
}

lcd_string(char *s)
{
    while(*s)
        dat(*s++);
}

void delay(int z)
{
  int i;
  for(i=0;i<=z;i++);
}	
	*/	
		

