#include <REGX51.H>
sfr led=0x80;
//sbit sw = P3^0;
void main()
{
	int i;
	//sw=1;
	//led=0;
	while(1)
	{
		//if(sw==0)
		//{
	led=0x0f;
	for(i=0;i<5000;i++);
	led=0xf0;
	for(i=0; i<5000;i++);
//}

}
	}