#include <REGX51.H>
sbit motp=P2^0;
sbit motn=P2^1;
void main()
{
	motp=motn=0;
	while(1)
	{
		motp=1;
		motn=0;
	}
}