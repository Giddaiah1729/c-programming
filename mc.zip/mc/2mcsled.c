#include <REGX51.H>
sbit led=P2^0;
sbit in=P1^0;
void main()
{
	while(1)
	{
		if(in==1)
		{
		led=1;
		}
		else
		{
		led=0;
		}
	}
}
