#include <REGX51.H>
sbit led=P2^1;
sbit sw=P3^1;
void main()
{
	sw=1;
	while(1)
	{
		if(sw==0)
		{
			led=1;
		}
		else
		{
			led=0;
		}
	}
}