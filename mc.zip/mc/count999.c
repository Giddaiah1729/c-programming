#include <REGX51.H>
sbit s1=P3^6;
sbit s2=P3^7;
//sbit s3=P3^6;
//sbit s4=P3^7;
void delay(int);

void main()
{
	int i,j;
	int d1,d2;
	char a[10]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};
	
	while(1)
	{
		for(i=0;i<99;i++)
		{
			d2=i%10;
			d1=i/10;
			for(j=0;j<10;j++)
			{
				s1=0;
				s2=1;
				P2=~a[d2];
        delay(5);
        s1=1;
        s2=0;
        P2=~a[d1];
        delay(5);
			}
		}
	}
}
void delay(int x)
	
{
	int k,l;
	for(k=0;k<x;k++)
	for(l=0;l<1275;l++);
}
	
