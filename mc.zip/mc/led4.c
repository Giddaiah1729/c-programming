#include <REGX51.H>
sbit led1 = P2^0;
sbit led2 = P2^1;
sbit led3 = P2^2;

void main()
{
	int i;
	while(1)
	{
	led1=1;
  led2 = 0;
  led3=0;
  for(i=0;i<100;i++);
  led1=0;
	led2=1;
	led3=0;
	for(i=0;i<100; i++);
	led1=0;
	led2=0;
	led3=1;
	for(i=0; i<100; i++);
}
	}
