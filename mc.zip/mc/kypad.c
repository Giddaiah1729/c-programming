#include <REGX51.H>
sbit r0=P1^0;
sbit r1=P1^1;
sbit r2=P1^2;
sbit r3=P1^3;
sbit c0=P1^4;
sbit c1=P1^5;
sbit c2=P1^6;
//sbit c3=P1^7;
sbit rs=P2^0;
sbit rw=P2^1;
sbit en=P2^2;
sfr lcd=0xB0;
void cmd(char );
void lcd_data(char );
//void show(char *);
void delay();

void main()
{
	//int i,j;
	//char key[4][4];
	
	cmd(0x38);
	delay();
	cmd(0x01);
	delay();
	cmd(0x0c);
	delay();
	cmd(0x06);
	delay();
	cmd(0x80);
	delay();
	
	
  //key[4][4]=('0', '1', '2','3','4','5','6','7','8','9','A','B','C','D','E','F');
	

	/*r0=r1=r2=r3=1;
	c0=c1=c2=0;
	if(r0==0) i=0;
	if(r1==0) i=1;
	if(r2==0) i=2;
	//if(r3==0) i=3;
	
	r0=r1=r2=r3=0;
	c0=c1=c2=1;
	if(c0==0) j=0;
	if(c1==0) j=1;
	if(c2==0) j=2;
	//if(c3==0) j=3;
	
	lcd_data(key[i][j]);

}
*/
while(1)
{
r0=0;
if(c0==0)
{
	lcd_data('1');
	delay();
}
if(c1==0)
{
	lcd_data('2');
	delay();
}
if(c2==0)
{
	lcd_data('3');
	delay();
}

r0=1,r1=0;
if(c0==0)
{
	lcd_data('4');
	delay();
}
if(c1==0)
{
	lcd_data('5');
	delay();
}

if(c2==0)
{
	lcd_data('6');
	delay();
}

r1=1,r2=0;
if(c0==0)
{
	lcd_data('7');
	delay();
}

if(c1==0)
{
	lcd_data('8');
	delay();
}

if(c2==0)
{
	lcd_data('9');
	delay();
}

r2=1,r3=0;
if(c0==0)
{
	lcd_data('*');
	delay();
}

if(c1==0)
{
	lcd_data('0');
	delay();
}

if(c2==0)
{
	lcd_data('#');
	delay();
}
r3=1;

}
}
void cmd(char x)
{
	P3=x;
	rs=0;
	rw=0;
	en=1;
	delay();
	en=0;
}
void lcd_data(char y)
{
	P3=y;
	rs=1;
	rw=0;
	en=1;
	delay();
	en=0;
}
/*
void show(char *z)
{
	while(*z)
	{
		lcd_data(*z++);
	}
}
*/
void delay()
{
	int i,j;
	for(i=0;i<10000;i++);
	for(j=0;j<10000;j++);
}

	
	
	
	
