#include <REGX51.H>
sbit led1=P2^1;
sbit led2=P2^2;
void extin0() interrupt 0
{
	EA=0;
	led1=~led1;
}
void extin1() interrupt 2
{
	EA=0;
	led2=~led2;
}
void main()
{
	EX0=1;
	EX1=1;
	EA=1;
	IT0=0;
	IT1=0;
	while(1)
	{
		int i;
		for(i=0;i<200;i++);
		EA=1;
	}
}