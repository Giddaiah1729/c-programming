#include <REGX51.H>
void mian()
{
	while(1)
	{
	TMOD=0x01;
  TH0=0x4B;
  TL0=0xFD;
  TR0=1;
  while(TF0==0);
  TF0=0;
  TR0=0;
}	
	}