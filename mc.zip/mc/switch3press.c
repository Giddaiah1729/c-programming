#include <REGX51.H>
sbit led = P2^0;
sbit sw = P2^6;
void main()
{
	int count;
	count = 0;
	while(1)
	{
		if(sw==0)
		{
			count = count + 1;
			while(sw==0);
		}
		if(count==3)
		{
			count = 0;
			led =~led;
		}
	}
}