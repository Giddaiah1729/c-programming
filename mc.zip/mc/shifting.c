#include <REGX51.H>
void main()
{
	int i;
	P2=0xff;
	while(1)
	{
		for(i=0;i<8;i++)
		P2=P2<<1;
	}
}