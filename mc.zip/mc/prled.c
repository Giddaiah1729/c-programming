#include <REGX51.H>
sbit led = P2^0;
void main()
{
	int i;
	while(1)
	{
	led=0;
	for(i=0;i<5000;i++);
	led = 1;
	for(i=0;i<5000;i++);
}
	}