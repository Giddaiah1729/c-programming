#include <REGX51.H>
sfr led=0xA0;
void main()
{
	TMOD=0x01;
	TH0=0xFE;
	TL0=0x33;
	TR0=1;
	while(TF0==0);
	TF0=0;
	TR0=0;
}