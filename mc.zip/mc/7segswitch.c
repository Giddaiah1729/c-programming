#include <REGX51.H>
sbit sw=P3^0;
void main()
{
	
	int i;
	sw=1;
	
	while(1)
	{
	if(sw==0)
	{
	P2=0x3F;
	for(i=0;i<30000;i++);
	P2=0x06;
	for(i=0;i<30000;i++);
	P2=0x5B;
	for(i=0;i<30000;i++);
	P2=0x4F;
	for(i=0;i<30000;i++);
	P2=0x66;
	for(i=0;i<30000;i++);
	P2=0x6D;
	for(i=0;i<30000;i++);
	P2=0x7D;
	for(i=0;i<30000;i++);
	P2=0x07;
	for(i=0;i<30000;i++);
	P2=0xFF;
	for(i=0;i<30000;i++);
	P2=0x6F;
	for(i=0;i<30000;i++);
		}
}
	}
	
	