#include<reg51.h>
sbit led1=P2^0;
sbit led2=P2^2;
sbit led3=P2^4;
sbit led4=P2^6;
void main()
{
	int i;
	while(1)
	{
		led1=0;
		for(i=0;i<5000;i++);
		led1=1;
		for(i=0;i<5000;i++);
		
		led2=0;
		for(i=0;i<5000;i++);
		led2=1;
		for(i=0;i<5000;i++);
		
		led3=0;
		for(i=0;i<5000;i++);
		led3=1;
		for(i=0;i<5000;i++);
		
		led4=0;
		for(i=0;i<5000;i++);
		led4=1;
		for(i=0;i<5000;i++);
	}
}