#include <REGX51.H>
sbit led1=P2^1;
sbit led2=P2^2;
int count = 0;
int seconds = 0;
int minutes = 0;
void extint0()interrupt 0
{
	EA=0;
	led1=~led1;
}
void extint1()interrupt 2
{
	EA=0;
	led2=~led2;
}
void extint2()interrupt 1
{
	EA=0;

	TH0=0x4B;
	TL0=0xFD;
	count = count +1;
	TF0=0;
}
void main()
{
	
	EX0=1;
	EX1=1;
	ET0=1;
	IT0=0;
	IT1=0;
	TMOD=0x01;
	TH0=0x4B;
	TL0=0xFD;
	TR0=1;
	while(1)
	{
	EA=1;
	if(count>19)
	{
		seconds+=1;
		count = 0;
	}
	if(seconds>59)
	{
		seconds=0;
		minutes+=1;
	}
}
	}
