#include <REGX51.H>
//#define lcd_data P2
sbit rs=P1^0;
sbit rw=P1^1;
sbit en=P1^2;

void cmd(char a);
void lcd_data(char b);
void show(char *s);
void delay();
void lcd_init()
{
	cmd(0x38);
	cmd(0x0c);
	cmd(0x06);
	cmd(0x01);
	cmd(0x80);
}
void cmd(char a)
{
	
	P2=a;
	rw=0;
	rs=0;
	en=1;
	delay();
	en=0;
}
void lcd_data(char b)
{
	
	P2=b;
	rw=0;
	rs=1;
	en=1;
	delay();
	en=0;
}
void show(char *s)
{
	while(*s)
	{
		lcd_data(*s++);
	}
}
void delay()
{
	int i;
	for(i=0;i<5000;i++);

}
int main()
{
	int j;
	lcd_init();
	
		while(1)
		{
			cmd(0x80);
			show("  Welcom To    ");
			cmd(0xc0);
			show("  My system   ");
			for(j=0;j<30000;j++);
			cmd(0x01);
			for(j=0;j<30000;j++);
		}
	}
