#include <REGX51.H>
//sbit LED =P2^0;
sfr LED = 0xA0; 
void main()
{
int i;
	while(1)
	{
		LED=1;
		for(i=0;i<5000;i++);
		LED=0;
		for(i=0;i<5000;i++);
	}
}