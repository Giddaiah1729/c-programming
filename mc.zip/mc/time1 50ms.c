#include <REGX51.H>
void delay();
int i;
void main()
{
	while(1)
	{
	P1=0x00;
	delay();
	P1=0xFF;
	delay();
}
	}
void delay()
{
	for(i=0;i<20;i++)
	{
	TMOD=0X01;
	TH0=0x35;
	TL0=0x00;
	TR0=1;
	while(TF0==0);
	TF0=0;
	TR0=0;
}
	}
	