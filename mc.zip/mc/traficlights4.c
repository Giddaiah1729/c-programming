#include <REGX51.H>
sbit r1=P2^0;
sbit y1=P2^1;
sbit g1=P2^2;

sbit r2=P2^5;
sbit y2=P2^6;
sbit g2=P2^7;

sbit r3=P1^0;
sbit y3=P1^1;
sbit g3=P1^2;

sbit r4=P1^5;
sbit y4=P1^6;
sbit g4=P1^7;
void delay(int x);

void main()
{
	while(1)
	{
		r1=1;y1=0;g1=0;
		r2=0;y2=1;g2=0;
		r3=0;y3=0;g3=1;
		r4=1;y4=0;g4=0;
		delay(60);
		
		r1=0;y1=1;g1=0;
		r2=0;y2=0;g2=1;
		r3=1;y3=0;g3=0;
		r4=1;y4=0;g4=0;
		delay(60);
		
		r1=1;y1=0;g1=0;
		r2=1;y2=0;g2=0;
		r3=0;y3=1;g3=0;
		r4=0;y4=0;g4=1;
		delay(60);
		
    r1=1;y1=0;g1=0;
		r2=0;y2=1;g2=0;
		r3=0;y3=0;g3=1;
		r4=1;y4=0;g4=0;
		delay(60);
	}	
}
		
void delay(int x)
{
	int i ;
	while(x--)
	{
		for(i=0;i<1275;i++);
		//for(j=0;j<5000;j++);
	}
}
	
	/*{
	P2=0x11;;
	P1=0x024;
	delay(10);
	P2=0x0c;
	P1=0x22;
	delay(10);
	P2=0x24;
	P1=0x11;
	delay(10);
	P2=0x22;
	P1=0x0c;
	delay(10);
}
	
}*/
