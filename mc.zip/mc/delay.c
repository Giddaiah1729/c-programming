#include <REGX51.H>
void delay(int);
sbit led = P2^0;
void main()
{
	while(1)
	{
led=0;
		delay(50);
	led=1;
		delay(50);

	}
}
void delay(int k)
{
	int i,j;
	for(i=0;i<k;i++)
	for(j=0;j<1275;j++);
}
