#include<REGX51.H>
void delay(int);
void lcd_str(char *str);
void lcd_data(char);
void lcd_cmd(char);
void adctoport(char value);

sbit rs=P3^0;
sbit rw=P3^1;
sbit en=P3^2;

sbit adc_rd=P3^5;
sbit adc_wr=P3^6;
sbit adc_intr=P3^7;

sfr adc=0x90;


void main()
{
lcd_cmd(0x38);
lcd_cmd(0x0c);
lcd_cmd(0x06);
lcd_cmd(0x01);
lcd_cmd(0x80);

lcd_cmd(0x80); 
lcd_str("hlo system");
lcd_cmd(0x01);

lcd_cmd(0x80);
lcd_str("temperature");

while(1)
{
adc_rd=1;
adc_wr=0;
delay(5);
adc_wr=1;
while(adc_intr==1);
delay(5);
adc_rd=0;
adc_intr=1;
lcd_cmd(0xc0);
adctoport(adc*4);
}
}
void adctoport(char value)
{
int x,d1,d2,d3;
x=value/10;
d3=value%10;
d2=x%10;
d1=x/10;

lcd_data(d1+'0');
lcd_data(d2+'0');
lcd_data(d3+'0');
}


void lcd_str(char *str)
{
while(*str)
lcd_data(*str++);
}

void lcd_cmd(char a)
{
P2=a;
rs=0;
rw=0;
en=1;
delay(5);
en=0;
}

void lcd_data(char b)
{
P2=b;
rs=1;
rw=0;
en=1;
delay(5);
en=0;
}

void delay(int k)
{
int i,j;
for(i=0;i<k;i++)
for(j=0;j<5000;j++);
}