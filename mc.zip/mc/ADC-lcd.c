#include <REGX51.H>
sbit rs=P3^5;
sbit rw=P3^6;
sbit en=P3^7;

void cmd(char a);
void lcd_data(char b);
void show(char *s);
void delay();
void main()
{
	float x;
	int Adcval;
	int d1,d2,d3,d4;
	cmd(0x38);
	cmd(0x0c);
	cmd(0x06);
	cmd(0x01);
	cmd(0x80);
	show("ADC TEST");
	while(1)
		{
			x=P1*0.0196;
			x=x*1000;
			Adcval=(int)x;
			cmd(0xC0);
			d1=Adcval%10;
			d2=(Adcval/10)%10;
			d3=(Adcval/100)%10;
			d4=Adcval/1000;
			cmd(0xc0);
			lcd_data(d4+48);
			lcd_data('.');
			lcd_data(d3+48);
			lcd_data(d2+48);
			lcd_data(d1+48);
			lcd_data('V');
			
}
		}
void cmd(char a)
{
	
	P2=a;
	rw=0;
	rs=0;
	en=1;
	delay();
	en=0;
}
void lcd_data(char b)
{
	
	P2=b;
	rw=0;
	rs=1;
	en=1;
	delay();
	en=0;
}
void show(char *s)
{
	while(*s)
	{
		lcd_data(*s++);
	}
}
void delay()
{
	int i;
	for(i=0;i<5000;i++);

}

