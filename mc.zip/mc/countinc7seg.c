#include <reg51.h>
sbit sw=P3^2;
void num();
void main()
{
while(1)
{
num();
}
}

void num()
{
    int a[]={0x40,0xF9,0x24,0x30,0x19,0x12,0x02,0xF8,0x00,0x10};
	  int count=0;
	 sw=1;
while(1)
{
if (sw==0)
{
while (sw == 0)
{
P2=a[count];	
}
sw=1;
count++;
if(count==10)
count=0;
}
}
}