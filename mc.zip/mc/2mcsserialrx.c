#include <REGX51.H>
sbit led=P2^0;
void main()
{
	led=0;
	TMOD=0x20;
	SCON=0x50;
	TH1=-3;
	TR1=1;
	while(1)
	{
	while(RI==0)
		RI=0;
	if(SBUF=='1')
	
	led=1;
	
	if(SBUF== '0')
	
		led=0;
	
}
	}
