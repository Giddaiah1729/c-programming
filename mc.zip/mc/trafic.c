#include <REGX51.H>
sbit led1=P2^0;
sbit led2=P2^1;
sbit led3=P2^2;
sbit led4=P2^3;
sbit led5=P2^4;
sbit led6=P2^5;
sbit led7=P1^1;
sbit led8=P1^2;
sbit led9=P1^3;
void main()
{
	int i;
	while(1)
	{
	  led1 =1;
		led2 =0;
		led3 =0;
		led4 =0;
		led5 =1;
		led6 =0;
		led7 =0;
		led8 =0;
		led9 =1;
		
		for(i=0; i<1000000; i++);
		
		led1 =0;
		led2 =1;
		led3 =0;
		led4 =0;
		led5 =0;
		led6 =1;
		led7 =1;
		led8 =0;
		led9 =0;
		for(i=0; i<1000000; i++);
		
		led1 =0;
		led2 =0;
		led3 =1;
		led4 =1;
		led5 =0;
		led6 =0;
		led7 =0;
		led8 =1;
		led9 =0;
		for(i=0; i<1000000; i++);
	}
}
		
		
