#include <REGX51.H>
sbit relay = P2^1;
void delay(int );
void main()
	
{
	while(1)
	{
	relay=0;
	delay(6000);
	relay=1;
	delay(6000);
}
	}
	void delay(int k)
	{
		int i,j;
		for(i=0;i<k;i++);
		for(j=0;j<1275; j++);
	}
	
	
	