#include <REGX51.H>
#define out_leds P2
#define keypad   P1
void main(void)
{
	out_leds = 0x00;
               while(1)
      {			
					keypad = 0xFE; 
				
          if(keypad == 0xee) 
					{
           out_leds = 1;
					}	
          if(keypad == 0xde) 
					{
           out_leds = 2;
					}	
					 if(keypad == 0xbe) 
					{
           out_leds = 3;
					}	
					
					keypad = 0xFD; 
					if(keypad == 0xED) 
					{
					out_leds = 4;
					}	
					if(keypad == 0xDD) 
					{
					out_leds = 5;
					}	
					 if(keypad == 0xBD) 
					{
					out_leds = 6;
					}	
					
					keypad = 0xFB; 
					if(keypad == 0xEB) 
					{
					out_leds = 7;
					}	
					if(keypad == 0xDB) 
					{
					out_leds = 8;
					}	
					 if(keypad == 0xBB) 
					{
					out_leds = 9;
					}	
					
						keypad = 0xF7; 
					if(keypad == 0xE7) 
					{
					out_leds = '*';
					}	
					if(keypad == 0xD7) 
					{
					out_leds = 0;
					}	
					 if(keypad == 0xB7) 
					{
					out_leds = '#';
					}	                        
									
       }
}