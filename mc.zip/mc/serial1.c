#include <REGX51.H>
void main()
{
	TMOD=0X20;
	TH1=0xfd;
	TR1=1;
	SCON=0x50;
	
	while(1)
	{ 
		SBUF='H';
		while(TI==0);
		TI=0;
 		SBUF='A';
		while(TI==0);
		TI=0;
	   SBUF='I';	
		while(TI==0);
		TI=0;
	}
}
		